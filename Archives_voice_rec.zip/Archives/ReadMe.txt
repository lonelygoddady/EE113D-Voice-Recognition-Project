************* Cereal Voice recognition system version 2.0 ****************

- Remeber to change the admin_status variable in the adjustable parameters from 0 to 1 to skip the user verification stage to admin menu.
- Almost all features of this system will not work if there is no library loaded in.
- Remember to change the file diretory to your library file location in the file_name_load() function.
- Even with our 70-word library, you will not past the user verification word test unless you are Ben.
- You will not be able to use the voice control feature because the system 'remembers' Ben's voices as the admin, the only person who can control the system.  
- You need to add the fft.h file yourself